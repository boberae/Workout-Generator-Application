*** README ***

To use the workout generator, run WorkoutGenerator.jar.

-->Select the muscle group you would like to generate the workout for.
-->Add or remove exercises as desired.
-->Choose the number of exercises for the generator to select from each exercise list. 
-->Press Finish when ready to generate
-->After generating, the workout will be displayed in the GUI, and you will have the option to send the workout via email.

The other .txt files packaged with this zip folder are used by the program to store default inputs for the text fields.